﻿define("epi-ecf-ui/contentediting/editors/VisitorGroupSelector", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/dom-construct",
    "dojo/when",
// epi
    "epi/dependency",
    "epi/shell/dgrid/util/misc",
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/widget/_ValueRequiredMixin",
// epi-ecf-ui
    "./VisitorGroupSelectorDialog",
    "../../widget/_SelectorBase",
// resources
    "epi/i18n!epi/nls/commerce.widget.visitorgroupselector"
], function (
// dojo
    array,
    declare,
    domConstruct,
    when,
// epi
    dependency,
    shellMisc,
    _FocusableMixin,
    _ValueRequiredMixin,
// epi-ecf-ui
    VisitorGroupSelectorDialog,
    _SelectorBase,
// resources
    resources
) {

    return declare([_SelectorBase, _ValueRequiredMixin, _FocusableMixin], {
        // tags: Represents a widget to select multiple visitor groups
        //      internal

        resources: resources,

        dialogTitle: resources.popuptitle,

        placeholderText: resources.novaluechosen,

        postCreate: function () {
            this.inherited(arguments);

            if (!this.store) {
                var registry = dependency.resolve("epi.storeregistry");
                this.store = registry.get("epi.cms.visitorgroup");
            }
        },

        _createDialogContent: function() {
            return new VisitorGroupSelectorDialog();
        },

        _setValueAttr: function(value) {
            // store the arguments in a variable to be able to use them inside a new closure.
            var args = arguments;
            this._setAllVisitorGroups().then(function(){
                this.inherited(args);
            }.bind(this));
        },

        _updateTextNode: function(visitorGroupIds) {
            var selectedVisitorGroups = null;
            if (visitorGroupIds){
                selectedVisitorGroups = this._convertIdsToVisitorGroups(visitorGroupIds);
            }
            // call the base function with the complete visitor group objects as the new arguments.
            this.inherited(arguments, [selectedVisitorGroups]);
        },

        _convertIdsToVisitorGroups: function (visitorGroupIds) {
            var visitorGroups = [],
                allVisitorGroups = this.get("allVisitorGroups");

            visitorGroupIds.forEach(function (visitorGroupId) {
                var visitorGroup = allVisitorGroups.filter(function (visitorGroup) {
                    return visitorGroup.id === visitorGroupId;
                })[0];

                if (visitorGroup) {
                    visitorGroups.push(visitorGroup);
                } else {
                    visitorGroups.push({ id: visitorGroupId, name: this.resources.deletedvisitorgroup });
                }
            }, this);

            return visitorGroups;
        },

        _setAllVisitorGroups: function() {
            return when(this.store.query()).then(function(allVisitorGroups){
                this.set("allVisitorGroups", allVisitorGroups || []);
            }.bind(this));
        },

        _getEllipsisTooltipLabel: function(notDisplayedItems) {
            // tags:
            //    protected, override
            var otherItems = '';
            notDisplayedItems.forEach(function(visitorGroup){
                otherItems += "<div>" + shellMisc.htmlEncode(visitorGroup.name) + "</div>";
            });
            return otherItems;
        },

        _onDialogShow: function () {
            // tags:
            //    protected, override

            when(this._setAllVisitorGroups()).then(function(){
                this.dialog.content.set("allVisitorGroups", this.get("allVisitorGroups"));
                this.dialog.content.set("selectedVisitorGroups", this.get("value"));
            }.bind(this));
        },

        _getDialogValue: function () {
            // tags:
            //    protected, override

            return this.dialog.content.get("selectedVisitorGroups");
        }
    });
});
