﻿define("epi-ecf-ui/contentediting/viewmodel/CategoryCollectionEditorModel", [
    // dojo
    "dojo/_base/declare",
    "dojo/topic",
    "dojo/when",

    // shell
    "epi/shell/selection",

    // epi-cms
    "epi-cms/contentediting/editors/model/CollectionEditorModel",
    "epi-cms/core/ContentReference",

    // ecf
    "./CategoryCollectionReadOnlyEditorModel",
    "./_RelationCollectionEditorModelMixin",
    "../../command/DetachFromCategory",

    // resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.categorycollectioneditor"
],
    function (
        //dojo
        declare,
        topic,
        when,

        // shell
        selection,

        // epi-cms
        CollectionEditorModel,
        ContentReference,

        // ecf
        CategoryCollectionReadOnlyEditorModel,
        _RelationCollectionEditorModelMixin,
        DetachFromCategory,

        // resources
        resources
    ) {
        return declare([CategoryCollectionReadOnlyEditorModel, _RelationCollectionEditorModelMixin], {
            // module:
            //      epi-ecf-ui/contentediting/viewmodel/CategoryCollectionEditEditorModel
            // summary:
            //      Represents the model for RelationCollectionEditor

            resources: resources,

            setSortOrderOnChange: false,

            _contentStructureStore: null,

            getItemCommands: function (item, availableCommands, category) {
                var commands = this.inherited(arguments);

                if (commands) {
                    for (var i = 0; i < commands.length; i++) {
                        if (commands[i].name === "remove") {
                            // Replace remove command with detach command
                            var removeCmd = commands[i];

                            var detachCmd = new DetachFromCategory({
                                name: removeCmd.name,
                                category: removeCmd.category,
                                label: removeCmd.label,
                                iconClass: removeCmd.iconClass,
                                selection: new selection(),
                                categoryLink: item.target,
                                isUsedByCollectionEditor: true
                            });
                            //Todo: move function out from for loop
                            /*jshint loopfunc:true */
                            when(this.getCurrentContent(), function (content) {
                                detachCmd.selection.data = [{ data: content, type: "epi.cms.contentdata" }];
                                detachCmd.set("model", {}); // This will trigger _onModelChange on the command.
                            });

                            commands[i] = detachCmd;
                        }
                    }
                }
                return commands;
            },

            addItem: function (item, refItem, before) {

                if (this.primaryCategory &&
                    ContentReference.compareIgnoreVersion(item.target, this.primaryCategory.target) &&
                    ContentReference.compareIgnoreVersion(item.source, this.primaryCategory.source)) {
                    return;
                }

                return when(this.inherited(arguments), function () {
                    topic.publish("relationChanged", item);
                });
            }
        });
    });