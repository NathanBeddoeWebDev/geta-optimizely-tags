﻿define("epi-ecf-ui/dgrid/_NoDataMessageMixin", [
    "dojo/_base/declare",
    "put-selector/put"
], function (
    declare,
    put
) {
    return declare([], {
        // summary:
        //      Extension for dgrids that want to show a no data message but not use _StoreMixin.
        //      The code is copied from dgrid/_StoreMixin
        // tags:
        //      internal

        refresh: function () {
            var result = this.inherited(arguments);

            this.noDataNode = put(this.contentNode, "div.dgrid-no-data");
            this.noDataNode.innerHTML = this.noDataMessage;

            return result;
        },

        renderArray: function () {
            var rows = this.inherited(arguments);

            if (rows.length && this.noDataNode) {
                put(this.noDataNode, "!");
            }

            return rows;
        }
    });
});