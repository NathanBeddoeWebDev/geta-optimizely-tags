﻿define("epi-ecf-ui/plugin-area/_CommerceEditViewFilter", [
// epi
    "epi/PluginArea",
    "epi-ecf-ui/contentediting/_ViewConfigurationsMixin"
], function (
// epi
    PluginArea,
    _ViewConfigurationsMixin
) {

    // summary:
    //      A plugin area to plugin custom view filtering for the view button dropdown.
    // tags:
    //      internal

    var pluginArea = new PluginArea("epi-cms/edit-view/filters[]");
    var filter = function () {
        return function (viewConfigurations, contentData, currentContext) {
            if (!contentData) {
                return viewConfigurations;
            }

            viewConfigurations.availableViews = (new _ViewConfigurationsMixin()).getAuthorizedViews(viewConfigurations.availableViews, contentData.accessMask);

            return viewConfigurations;
        };
    };

    pluginArea.add(filter);

    return pluginArea;
});