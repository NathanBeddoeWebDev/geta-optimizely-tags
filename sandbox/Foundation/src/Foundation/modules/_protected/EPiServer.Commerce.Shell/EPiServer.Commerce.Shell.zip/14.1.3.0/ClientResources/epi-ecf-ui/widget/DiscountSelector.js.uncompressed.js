﻿define("epi-ecf-ui/widget/DiscountSelector", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/dom-construct",
// epi
    "epi/shell/dgrid/util/misc",
// epi-cms
    "epi-cms/core/ContentReference",
// epi-ecf-ui
    "./_MarketingItemTag",
    "../MarketingUtils",
    "./_SelectorBase",
    "./DiscountSelectorDialog",
// resources
    "epi/i18n!epi/nls/commerce.widget.discountselector"
],

function (
// dojo
    array,
    declare,
    domConstruct,
// epi
    shellMisc,
// epi-cms
    ContentReference,
// epi-ecf-ui
    _MarketingItemTag,
    MarketingUtils,
    _SelectorBase,
    DiscountSelectorDialog,
// resources
    resources
) {

    return declare([_SelectorBase], {
        // tags: Represents a widget to select multiple campaign, discount.
        //      internal

        resources: resources,

        dialogTitle: resources.popuptitle,

        placeholderText: resources.novaluechosen,

        // excludedLink: [public] String
        //      Content reference of the discount, which should not be displayed on the tree.
        excludedLink: null,

        campaignRootFolder: null,

        store: null,

        postCreate: function () {
            this.inherited(arguments);
            this._itemTagType = _MarketingItemTag;
        },

        _createDialogContent: function() {
            return new DiscountSelectorDialog({
                root: this.campaignRootFolder,
                store: this.store
            });
        },

        _setValueAttr: function (value) {
            //summary:
            //    Value's setter.
            //
            // value: array of content data.
            //    Value to be set.
            //
            // tags:
            //    protected

            this._sortItems(value);
            this.inherited(arguments, [value]);
        },

        _convertTypeIdentifierToNumber: function (item) {
            //summary:
            //    convert type identifier of a marketing item to number
            //    in order to compare two items
            //
            // item: marketing item.
            //
            // tags:
            //    private

            return MarketingUtils.isPromotionData(item.typeIdentifier) ? 2 : MarketingUtils.isSalesCampaign(item.typeIdentifier) ? 1 : 0;
        },

        _sortItems: function (value) {
            //summary:
            //    sort items: root first, then campaigns, and finally promotions.
            //
            // value: array of content data.
            //
            // tags:
            //    private

            value.sort(function (a, b) {
                return this._convertTypeIdentifierToNumber(a) - this._convertTypeIdentifierToNumber(b);
            }.bind(this));
        },

        _getEllipsisTooltipLabel: function(notDisplayedItems) {
            var otherItemPaths = '';
            array.forEach(notDisplayedItems, function (item) {
                if (MarketingUtils.isPromotionData(item.typeIdentifier)) {
                    otherItemPaths += "<div>" + shellMisc.htmlEncode(item.properties.campaignName + " / " + item.name) + "</div>";
                } else {
                    otherItemPaths += "<div>" + shellMisc.htmlEncode(item.name) + "</div>";
                }
            });

            return otherItemPaths;
        },

        _isItemEqual: function (itemToRemove, listEntry) {
            // summary:
            //    For this selector the item to remove is a the content references and the stored items are content data.
            //
            // tags:
            //    protected, abstract

            return ContentReference.compareIgnoreVersion(itemToRemove, listEntry.contentLink);
        },

        _onDialogShow: function () {
            this.dialog.content.set("excludedLink", this.get("excludedLink"));
            this.dialog.content.set("checkedItems", this.get("value"));

            this.dialog.content.onShow();
        },

        _getDialogValue: function () {
            return this.dialog.content.get("checkedItems");
        }
    });
});
