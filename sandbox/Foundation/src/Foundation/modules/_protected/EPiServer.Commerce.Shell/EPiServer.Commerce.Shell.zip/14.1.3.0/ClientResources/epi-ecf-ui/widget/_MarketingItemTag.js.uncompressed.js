define("epi-ecf-ui/widget/_MarketingItemTag", [
// dojo
    "dojo/_base/declare",
// epi
    "epi/shell/dgrid/util/misc",
// epi-ecf-ui
    "../MarketingUtils",
    "./SelectorItemTag"
], function (
// dojo
    declare,
// epi
    shellMisc,
// epi-ecf-ui
    MarketingUtils,
    SelectorItemTag
) {

    return declare([SelectorItemTag], {
        // summary:
        //      A widget represents a button tag of an marketing item.
        // tags:
        //      internal

        _onClick : function () {
            this.onRemoveClick(this.item.contentLink);
        },

        _getTooltipLabel: function () {
            // summary:
            //    Return the path to a campaign/promotion excluding root.
            // item:
            //    the marketing item (campaign/promotion)
            // tags:
            //    private

            if (MarketingUtils.isPromotionData(this.item.typeIdentifier)) {
                return shellMisc.htmlEncode(this.item.properties.campaignName + ' / ' + this.item.name);
            }

            return this.inherited(arguments);
        }
    });
});