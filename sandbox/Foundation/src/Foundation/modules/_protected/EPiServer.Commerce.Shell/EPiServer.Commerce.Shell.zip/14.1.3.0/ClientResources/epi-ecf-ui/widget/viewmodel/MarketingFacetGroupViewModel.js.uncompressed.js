﻿define("epi-ecf-ui/widget/viewmodel/MarketingFacetGroupViewModel", [
// dojo
    "dojo/_base/declare",
// epi
    "epi-ecf-ui/MarketingUtils",
    "epi-ecf-ui/widget/viewmodel/FacetGroupViewModel"
], function (
// dojo
    declare,
// epi
    MarketingUtils,
    FacetGroupViewModel
) {

    return declare([FacetGroupViewModel], {
        // summary:
        //      View model for marketing "FacetGroup" widget.
        // tags:
        //      public

        getIconClasses: function (item) {
            // summary:
            //      Gets icon CSS classes for the given object.
            // item: [Object]
            //      Object to render properly icon CSS classes.
            // returns: [string]
            //      Icon CSS classes for the given object.
            // tags:
            //      public, extensions

            return this.inherited(arguments) || (this.hasIcons && MarketingUtils.getItemIconClass(this.get("id"), item.id));
        }

    });

});