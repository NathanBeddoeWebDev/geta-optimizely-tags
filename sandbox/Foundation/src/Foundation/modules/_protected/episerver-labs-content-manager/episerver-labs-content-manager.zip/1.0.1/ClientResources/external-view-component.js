define([
    "dojo/_base/declare",
    "dojo/on",

    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

    "epi/dependency",
    "epi-cms/widget/ContentSelector",

    "episerver-labs-content-manager/external-details-form",
    "episerver-labs-content-manager/notifications-hub",

    "dojo/text!episerver-labs-content-manager/external-view-component.html",

    // references required by dijit template parser
    "dijit/form/Button",

    "xstyle/css!./styles.css"
],
    function (
        declare,
        on,

        _LayoutWidget,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,

        dependency,
        ContentSelector,

        ExternalDetailsForm,

        notificationsHubInitializer,

        template
    ) {

        notificationsHubInitializer();

        var originalButtonClick = ContentSelector.prototype._onButtonClick;
        ContentSelector.prototype._onButtonClick = function () {
            var firstArgument = arguments[0];
            if (firstArgument.preventDefault) {
                firstArgument.preventDefault();
                firstArgument.stopPropagation();
            }

            originalButtonClick.apply(this, arguments);
        };

        return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin], {
            templateString: template,

            postCreate: function () {
                this.inherited(arguments);

                window.externalGridContentEdit.onEditItem = this._onEditItem.bind(this);
                window.externalGridContentEdit.onSetContentLanguage = this._onSetContentLanguage.bind(this);
                window.externalGridContentEdit.onCancelReview = this._onCancelReview.bind(this);
                window.externalGridContentEdit.onCreateContent = this._onCreateContent.bind(this);
                window.externalGridContentEdit.onTranslate = this._onTranslate.bind(this);
            },

            startup: function () {
                if (this._started) {
                    return;
                }

                this.inherited(arguments);

                var moduleManager = dependency.resolve("epi.ModuleManager");
                this.params.externalModules.forEach(function (externalModule) {
                    moduleManager.startModules(externalModule);
                }.bind(this));

                this.profile = dependency.resolve("epi.shell.Profile");
            },

            _onEditItem: function (contentLink, divToRenderIn, callback) {
                this.contentDetailsForm.editContent(contentLink, divToRenderIn, callback);
            },

            _onSetContentLanguage: function(languageId) {
                return this.profile.setContentLanguage(languageId);
            },

            _onCancelReview: function (contentLink) {
                return this.contentDetailsForm.cancelReview(contentLink);
            },

            _onCreateContent: function (contentTypeId, parentContentId, divToRenderIn, callback) {
                this.contentDetailsForm.createContent(contentTypeId, parentContentId, divToRenderIn, callback);
            },

            _onTranslate: function (contentLink, language, divToRenderIn, callback) {
                this.contentDetailsForm.translateContent(contentLink, language, divToRenderIn, callback);
            }
        });
    });
