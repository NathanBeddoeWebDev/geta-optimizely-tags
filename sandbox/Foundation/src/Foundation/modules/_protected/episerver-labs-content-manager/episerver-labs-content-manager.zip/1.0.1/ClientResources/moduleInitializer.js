define([
    "dojo/_base/declare",
    "dojo/when",

    "epi/_Module",
    "epi/routes",

    "epi/shell/applicationSettings",
    "epi-cms/contentediting/command/BlockEdit",
    "epi-cms/contentediting/command/BlockInlineEdit",

    "epi/shell/store/JsonRest"
], function (
    declare,
    when,

    _Module,
    routes,

    applicationSettings,
    BlockEdit,
    BlockInlineEdit,
    JsonRest
) {
    return declare([_Module], {
        initialize: function () {
            this.inherited(arguments);

            if (!applicationSettings.isInContentManagerMode) {
                return;
            }

            var registry = this.resolveDependency("epi.storeregistry");

            // Register Children store
            registry.add("content-manager.store",
                new JsonRest({
                    target: routes.getRestPath({ moduleArea: "episerver-labs-content-manager", storeName: "content-manager" }),
                    idProperty: "contentLink"
                })
            );

            // hide 'Edit' ContentArea menu
            var originalOnModelChange = BlockEdit.prototype._onModelValueChange;
            BlockEdit.prototype._onModelValueChange = function () {
                originalOnModelChange.apply(this, arguments);

                this.set("isAvailable", false);
            };

            // method body copied from CMS
            BlockInlineEdit.prototype._onModelChange = function () {
                this.inherited(arguments);

                if (this.model instanceof Array) {
                    if (this.model.length === 1) {
                        this.model = this.model[0];
                    } else {
                        this.model = null;
                    }
                }

                if (!this.model) {
                    this.set("canExecute", false);
                    return;
                }

                // Do not check type of content.
                // In content manager allow edit all types of content

                /*if (!TypeDescriptorManager.isBaseTypeIdentifier(this.model.typeIdentifier, "episerver.core.blockdata")) {
                    this.set("isAvailable", false);
                    return;
                }*/

                if (this.model.isOverlayInitialized === false) {
                    return;
                }

                when(this._getContentData()).then(function (contentData) {
                    this._refreshContentSettings(contentData);
                }.bind(this));
            };
            BlockInlineEdit.prototype._onModelChange.nom = "_onModelChange";
        }
    });
});
